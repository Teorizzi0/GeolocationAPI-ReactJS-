import React, { useState } from 'react';
import './App.css';

function App() {
  const [status, setStatus] = useState('')
  return (
    <div className="App">
      <button onClick={() => {
        const start = Date.now()
        console.log('starts at', start)
        const success = (position) => {
          const latitude = position.coords.latitude;
          const longitude = position.coords.longitude;
          setStatus(`lat: ${latitude}, lng: ${longitude}`)
          console.log('ends at', Date.now())
          console.log('time took', Date.now() - start)
        }

        const error = () => {
          setStatus('Unable to retrieve your location');
        }

        if (!navigator.geolocation) {
          console.log('Geolocation is not supported by your browser');
        } else {
          setStatus('Locating…')
          navigator.geolocation.getCurrentPosition(success, error);
        }

      }

      }>Click </button>
      <div>{status}</div>
    </div>
  );
}

export default App;
